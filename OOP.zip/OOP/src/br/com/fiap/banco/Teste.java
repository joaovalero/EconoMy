package br.com.fiap.banco;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Teste {

	public static void main(String[] args) throws ParseException {
					
			
			SimpleDateFormat df = new SimpleDateFormat("DD/MM/yyyy");
			//DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
					
			Date data_nasc1 = df.parse("01/01/2000");
			Usuario usuario = new Usuario(1234, "M", "Leonardo", "Alves", data_nasc1);
			
			usuario.consultarUsuario();
			System.out.println("\n");
			
			Date data_nasc2 = df.parse("01/01/2001");
			Contato contato = new Contato(4654, "F", "Fernanda", "Silva", data_nasc2, "3857-5555","945463217", 11, "email@fiap.com.br");
			
			contato.consultarContato();
			System.out.println("\n");
			
			Date data_nasc3 = df.parse("01/01/2002");
			Endereco endereco = new Endereco(456475, "M", "Augusto", "Silva", data_nasc3, "02777031","Rua", "Baruel de Almeida", 50, "Vila Leopoldina", "Apto 11 - Torre A", "S�o Paulo", "SP");
			
			endereco.consultarEndereco();
			System.out.println("\n");
			
			Date data_nasc4 = df.parse("01/01/2003");
			Date data_recebiveis = df.parse("01/01/2021");
			Recebiveis recebiveis = new Recebiveis(4657879, "M", "Jorge", "Alberto", data_nasc4, 150.0f, data_recebiveis, "Camiseta");
			
			recebiveis.consultarRecebiveis();
			System.out.println("\n");
			
			Date data_nasc5 = df.parse("01/01/2004");
			Date data_despesa = df.parse("01/01/2020");
			Despesas despesas = new Despesas(879874, "F", "Joana", "Gon�alves", data_nasc5, 50.0f, data_despesa,"Martelo");
			
			despesas.consultarDespesas();
			System.out.println("\n");
			
			Date data_nasc6 = df.parse("01/01/2005");
			Login login = new Login(456465465, "F", "Ana", "Joaquina", data_nasc6, "3646-3003","95561-4123", 11, "email2@fiap.com.br", "email2@fiap.com.br", "senha123");
			
			login.imprime();
			System.out.println("\n");
			
			System.out.println(login.efetuarLogin("email2@fiap.com.br","senha123"));
			
			
			
	}
}

