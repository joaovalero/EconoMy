package br.com.fiap.banco;

import java.text.DateFormat;
import java.util.Date;

public class Despesas extends Usuario{

	//private int id_despesas;
	private float vl_despesas;
	private Date dt_despesas;
	private String ds_despesas;
	
	DateFormat dfm = DateFormat.getDateInstance(DateFormat.SHORT);
	public Despesas(int nr_cpf, String sexo, String nm_usuario, String ds_sobrenome, Date dt_nasc, float vl_despesas, Date dt_despesas, String ds_despesas) {
		super(nr_cpf, sexo, nm_usuario, ds_sobrenome, dt_nasc);
		this.vl_despesas = vl_despesas;
		this.dt_despesas = dt_despesas;
		this.ds_despesas = ds_despesas;
	}
	
	/*public int getId_despesas() {
		return id_despesas;
	}
	public void setId_despesas(int id_despesas) {
		this.id_despesas = id_despesas;
	}*/
	public float getVl_despesas() {
		return vl_despesas;
	}
	public void setVl_despesas(float vl_despesas) {
		this.vl_despesas = vl_despesas;
	}
	public Date getDt_despesas() {
		return dt_despesas;
	}
	public void setDt_despesas(Date dt_despesas) {
		this.dt_despesas = dt_despesas;
	}
	public String getDs_despesas() {
		return ds_despesas;
	}
	public void setDs_despesas(String ds_despesas) {
		this.ds_despesas = ds_despesas;
	}
	
	//m�todo
	public void consultarDespesas() {
		super.consultarUsuario();
		System.out.println("Valor da Despesa: " + this.vl_despesas);
		System.out.println("Desc. da Despesa: " + this.ds_despesas);
		System.out.println("Data da Despesa: " + dfm.format(this.dt_despesas));

	}
	
	
}
