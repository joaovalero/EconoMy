package br.com.fiap.banco;
import java.util.Date;
import java.text.DateFormat;


public class Usuario {

	private int nr_cpf;
	private String sexo;
	private String nm_usuario;
	private String ds_sobrenome;
	private Date dt_nasc;
		
	DateFormat dfm = DateFormat.getDateInstance(DateFormat.SHORT);
	public Usuario(int nr_cpf, String sexo, String nm_usuario, String ds_sobrenome, Date dt_nasc) {
		super();
		this.nr_cpf = nr_cpf;
		this.sexo = sexo;
		this.nm_usuario = nm_usuario;
		this.ds_sobrenome = ds_sobrenome;
		this.dt_nasc = dt_nasc;
	}
	
	public Usuario() {
		super();
	}

	public int getNr_cpf() {
		return nr_cpf;
	}
	public void setNr_cpf(int nr_cpf) {
		this.nr_cpf = nr_cpf;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public String getNm_usuario() {
		return nm_usuario;
	}
	public void setNm_usuario(String nm_usuario) {
		this.nm_usuario = nm_usuario;
	}
	public String getDs_sobrenome() {
		return ds_sobrenome;
	}
	public void setDs_sobrenome(String ds_sobrenome) {
		this.ds_sobrenome = ds_sobrenome;
	}
	public Date getDt_nasc() {
		return dt_nasc;
	}
	public void setDt_nasc(Date dt_nasc) {
		this.dt_nasc = dt_nasc;
	}

	//m�todo
	
	/*public void cadastrarUsuario(int nr_cpf, String sexo, String nm_usuario, String ds_sobrenome, Date dt_nasc) {
		this.nr_cpf = nr_cpf;
		this.sexo = sexo;
		this.nm_usuario = nm_usuario;
		this.ds_sobrenome = ds_sobrenome;
		this.dt_nasc = dt_nasc;
	}*/
	
	public void consultarUsuario() {
		System.out.println("Nome do usu�rio: " + this.nm_usuario);
		System.out.println("Sobrenome: " + this.ds_sobrenome);
		System.out.println("Cpf: " + this.nr_cpf);
		System.out.println("Sexo: " + this.sexo);
		System.out.println("Data de nascimento: " + dfm.format(this.dt_nasc));
	}
	
}
