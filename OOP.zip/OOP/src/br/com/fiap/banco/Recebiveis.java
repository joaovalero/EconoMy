package br.com.fiap.banco;
import java.text.DateFormat;
import java.util.Date;


public class Recebiveis extends Usuario{

	//private int id_recebiveis;
	private float vl_recebiveis;
	private Date dt_recebiveis;
	private String ds_recebiveis;
	DateFormat dfm = DateFormat.getDateInstance(DateFormat.SHORT);
	
	public Recebiveis(int nr_cpf, String sexo, String nm_usuario, String ds_sobrenome, Date dt_nasc, float vl_recebiveis, Date dt_recebiveis, String ds_recebiveis) {
		super(nr_cpf, sexo, nm_usuario, ds_sobrenome, dt_nasc);
		this.vl_recebiveis = vl_recebiveis;
		this.dt_recebiveis = dt_recebiveis;
		this.ds_recebiveis = ds_recebiveis;
	}
	/*public int getId_recebiveis() {
		return id_recebiveis;
	}
	public void setId_recebiveis(int id_recebiveis) {
		this.id_recebiveis = id_recebiveis;
	}*/
	public float getVl_recebiveis() {
		return vl_recebiveis;
	}
	public void setVl_recebiveis(float vl_recebiveis) {
		this.vl_recebiveis = vl_recebiveis;
	}
	public Date getDt_recebiveis() {
		return dt_recebiveis;
	}
	public void setDt_recebiveis(Date dt_recebiveis) {
		this.dt_recebiveis = dt_recebiveis;
	}
	public String getDs_recebiveis() {
		return ds_recebiveis;
	}
	public void setDs_recebiveis(String ds_recebiveis) {
		this.ds_recebiveis = ds_recebiveis;
	}
	
	//m�todo
	public void consultarRecebiveis() {
		super.consultarUsuario();
		System.out.println("Valor do Receb�vel: " + this.vl_recebiveis);
		System.out.println("Desc. do Receb�vel: " + dfm.format(this.dt_recebiveis));
		System.out.println("Data do Receb�vel: " + this.ds_recebiveis);

	}
	
	
}
