package br.com.fiap.banco;

import java.util.Date;

public class Login extends Contato{

	//private int id_login;
	private String usuario;
	private String senha;

	
	/*public int getId_login() {
		return id_login;
	}
	public void setId_login(int id_login) {
		this.id_login = id_login;
	}*/
	
	public Login(int nr_cpf, String sexo, String nm_usuario, String ds_sobrenome, Date dt_nasc, String nr_telefone_fixo,
			String nr_celular, int nr_ddd, String ds_email, String usuario, String senha) {
		super(nr_cpf, sexo, nm_usuario, ds_sobrenome, dt_nasc, nr_telefone_fixo, nr_celular, nr_ddd, ds_email);
		this.usuario = usuario;
		this.senha = senha;
	}
	public String getUsuario() {
		return usuario;
	}
	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}
	
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}

	//m�todo
	public void imprime() {
		super.consultarContato();
		System.out.println("Usu�rio: " + this.usuario);
		System.out.println("Senha: " + this.senha);

	}
	
	public String efetuarLogin(String usuario, String senha) {
		return "Bem-vindo � plataforma Fintech";
	}


	
	
}
