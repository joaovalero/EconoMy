package br.com.fiap.banco;

import java.util.Date;

public class Endereco extends Usuario{

	//private int id_endereco;
	private String nr_cep;
	private String nm_logradouro;
	private String ds_endereco;
	private int nr_endereco;
	private String nm_bairro;
	private String ds_complemento;
	private String ds_Cidade;
	private String ds_uf;
	
	/*public int getId_endereco() {
		return id_endereco;
	}
	public void setId_endereco(int id_endereco) {
		this.id_endereco = id_endereco;
	}*/
	
	public Endereco(int nr_cpf, String sexo, String nm_usuario, String ds_sobrenome, Date dt_nasc, String nr_cep, String nm_logradouro, String ds_endereco, int nr_endereco, String nm_bairro, String ds_complemento, String ds_Cidade, String ds_uf) {
		super(nr_cpf, sexo, nm_usuario, ds_sobrenome, dt_nasc);
		this.nr_cep = nr_cep;
		this.nm_logradouro = nm_logradouro;
		this.ds_endereco = ds_endereco;
		this.nr_endereco = nr_endereco;
		this.nm_bairro = nm_bairro;
		this.ds_complemento = ds_complemento;
		this.ds_Cidade = ds_Cidade;
		this.ds_uf = ds_uf;
	}
	
	public String getNr_cep() {
		return nr_cep;
	}

	public void setNr_cep(String nr_cep) {
		this.nr_cep = nr_cep;
	}
	public String getDs_endereco() {
		return ds_endereco;
	}
	public void setDs_endereco(String ds_endereco) {
		this.ds_endereco = ds_endereco;
	}
	public int getNr_endereco() {
		return nr_endereco;
	}
	public void setNr_endereco(int nr_endereco) {
		this.nr_endereco = nr_endereco;
	}
	public String getNm_logradouro() {
		return nm_logradouro;
	}
	public void setNm_logradouro(String nm_logradouro) {
		this.nm_logradouro = nm_logradouro;
	}
	public String getNm_bairro() {
		return nm_bairro;
	}
	public void setNm_bairro(String nm_bairro) {
		this.nm_bairro = nm_bairro;
	}
	public String getDs_complemento() {
		return ds_complemento;
	}
	public void setDs_complemento(String ds_complemento) {
		this.ds_complemento = ds_complemento;
	}
	public String getDs_Cidade() {
		return ds_Cidade;
	}
	public void setDs_Cidade(String ds_Cidade) {
		this.ds_Cidade = ds_Cidade;
	}
	public String getDs_uf() {
		return ds_uf;
	}
	public void setDs_uf(String ds_uf) {
		this.ds_uf = ds_uf;
	}
	
	//m�todo
	public void consultarEndereco() {
		super.consultarUsuario();
		System.out.println("Cep: " + this.nr_cep);
		System.out.println("Logradouro: " + this.nm_logradouro);
		System.out.println("Endere�o: " + this.ds_endereco);
		System.out.println("Bairro: " + this.nm_bairro);
		System.out.println("Complemento: " + this.ds_complemento);
		System.out.println("Cidade: " + this.ds_Cidade);
	}
	
}
