package br.com.fiap.banco;

import java.util.Date;

public class Contato extends Usuario{
	
	//private int id_contato;
	private String nr_telefone_fixo;
	private String nr_celular;
	private int nr_ddd;
	private String ds_email;
	
	/*public int getId_contato() {
		return id_contato;
	}
	
	public void setId_contato(int id_contato) {
		this.id_contato = id_contato;
	}
	*
	*/
	
	public Contato(int nr_cpf, String sexo, String nm_usuario, String ds_sobrenome, Date dt_nasc, String nr_telefone_fixo, String nr_celular, int nr_ddd, String ds_email) {
		super(nr_cpf, sexo, nm_usuario, ds_sobrenome, dt_nasc);
		this.nr_telefone_fixo = nr_telefone_fixo;
		this.nr_celular = nr_celular;
		this.nr_ddd = nr_ddd;
		this.ds_email = ds_email;
	}

	public String getNr_telefone_fixo() {
		return nr_telefone_fixo;
	}
	public void setNr_telefone_fixo(String nr_telefone_fixo) {
		this.nr_telefone_fixo = nr_telefone_fixo;
	}
	public String getNr_celular() {
		return nr_celular;
	}
	public void setNr_celular(String nr_celular) {
		this.nr_celular = nr_celular;
	}
	public int getNr_ddd() {
		return nr_ddd;
	}
	public void setNr_ddd(int nr_ddd) {
		this.nr_ddd = nr_ddd;
	}
	public String getDs_email() {
		return ds_email;
	}
	public void setDs_email(String ds_email) {
		this.ds_email = ds_email;
	}
	
	//m�todo
	
	/*public void cadastrarContato(String nr_telefone_fixo, String nr_celular, int nr_ddd, String ds_email) {
		this.nr_telefone_fixo = nr_telefone_fixo;
		this.nr_celular = nr_celular;
		this.nr_ddd = nr_ddd;
		this.ds_email = ds_email;
	}*/
	
	public void consultarContato() {
		super.consultarUsuario();
		System.out.println("Telefone: " + this.nr_telefone_fixo);
		System.out.println("Celular: " + this.nr_celular);
		System.out.println("DDD: " + this.nr_ddd);
		System.out.println("Celular: " + this.ds_email);
	}
	


		
}
