import java.sql.SQLException;

import br.com.fiap.bancodadoson.dao.ProdutoDAO;
import br.com.fiap.bancodadoson.model.ProdutoModel;

public class ProdutoInserirView {

	public static void main(String[] args) throws SQLException {
		
		ProdutoModel model = new ProdutoModel();
		model.setCd_usuario(12);
		model.setNm_nome("Joao");
		model.setCpf_usuario("123456789");
		model.setDs_endereco("rua teste");
		model.setNm_agencia(1234);
		model.setNm_conta(123456);
		
		
		ProdutoDAO dao = new ProdutoDAO();
		dao.insert(model);
		
	}

}
