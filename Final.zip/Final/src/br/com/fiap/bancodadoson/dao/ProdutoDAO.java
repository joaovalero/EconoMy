package br.com.fiap.bancodadoson.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.Statement;

import br.com.fiap.bancodadoson.model.ProdutoModel;

public class ProdutoDAO {
	
	
	private List<ProdutoModel> listaProdutos;

	public ProdutoModel findById(int id) {
		ProdutoModel produtoModel = null;
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL", "RM96090", "300994");
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM T_SIP_CADASTRO WHERE ID = " + id);
	
			if (rs.next() ) {
				produtoModel = new ProdutoModel();
				produtoModel.setNm_nome(rs.getString("Jose"));
				produtoModel.setCd_usuario(rs.getInt(123));
				produtoModel.setNm_conta(rs.getInt(3216));
				
			}
			
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return produtoModel;
		
	
	}
	
	
public List<ProdutoModel> findAll(){
	List<ProdutoModel> listaProdutos = new ArrayList<ProdutoModel>();
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL", "RM96090", "300994");
		
		Statement stmt = conn.createStatement();
		
		ResultSet rs = stmt.executeQuery("SELECT * FROM T_SIP_CADASTRO");

		
		ProdutoModel produtoModel;
		while ( rs.next() ) {
			produtoModel = new ProdutoModel();
			produtoModel.setCd_usuario(rs.getInt("cd_usuario"));
			produtoModel.setNm_nome(rs.getString("nm_nome"));
			produtoModel.setCpf_usuario(rs.getString("cpf_usuario"));
			produtoModel.setDs_endereco(rs.getString("ds_endereco"));
			produtoModel.setNm_agencia(rs.getInt("nm_agencia"));
			produtoModel.setNm_conta(rs.getInt("nm_conta"));
			
			
			listaProdutos.add(produtoModel);
			
			
		}
	
} catch (ClassNotFoundException e) {
	e.printStackTrace();
}catch (SQLException e) {
	e.printStackTrace();
}
	
	return listaProdutos; 
}


	
public void insert(ProdutoModel produtoModel) throws SQLException{
	String SQL = 
			"INSERT INTO T_SIP_CADASTRO (CD_USUARIO, NM_NOME, CPF_USUARIO, DS_ENDERECO, NM_AGENCIA, NM_CONTA )"
			+ " VALUES (SEQ_CADASTRO.nextval, ?, ?, ?, ?, ?)";
	
	Connection conn = null; 
	
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		conn=DriverManager.getConnection("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL", "RM96090", "300994");
		PreparedStatement ptmt = conn.prepareStatement(SQL);
		
		ptmt.setInt(1, produtoModel.getCd_usuario());
		ptmt.setString(2, produtoModel.getNm_nome());
		ptmt.setString(3, produtoModel.getCpf_usuario());
		ptmt.setString(4, produtoModel.getDs_endereco());
		ptmt.setInt(5, produtoModel.getNm_agencia());
		ptmt.setInt(3, produtoModel.getNm_conta());
		
		ptmt.execute();
	
}catch (ClassNotFoundException e) {
	e.printStackTrace();
	}finally {
		conn = null;
	}
	
}

public void update(ProdutoModel produtoModel) throws SQLException {
	String SQL = 
			"UPDATE T_SIP_CADASTRO SET NM_NOME = ?, DS_ENDERECO = ? ";
			
	
	Connection conn = null; 
	
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		conn=DriverManager.getConnection("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL", "RM96090", "300994");
		PreparedStatement ptmt = conn.prepareStatement(SQL);
		
		ptmt.setString(1, produtoModel.getNm_nome());
		ptmt.setString(2, produtoModel.getDs_endereco());
		
		
		ptmt.execute();
	
}catch (ClassNotFoundException e) {
	e.printStackTrace();
	}finally {
		conn = null;
	}
	
}
	


public void delete(ProdutoModel produtoModel) throws SQLException {
	String SQL = 
			"DELETE FROM T_SIP_CADASTRO WHERE CD_USUARIO = ?";
			
	
	Connection conn = null; 
	
	try {
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		conn=DriverManager.getConnection("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL", "RM96090", "300994");
		PreparedStatement del = conn.prepareStatement(SQL);
		
		del.setInt(1, produtoModel.getCd_usuario());
		
		
		del.execute();
	
}catch (ClassNotFoundException e) {
	e.printStackTrace();
	}finally {
		conn = null;
	}
	
}
	
	
}




