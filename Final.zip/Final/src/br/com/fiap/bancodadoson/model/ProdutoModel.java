package br.com.fiap.bancodadoson.model;

public class ProdutoModel {
	private int cd_usuario;
	private String nm_nome;
	private String cpf_usuario;
	private String ds_endereco; 
	private int nm_agencia; 
	private int nm_conta;
	
	public ProdutoModel() {
		
	}
	
	public ProdutoModel(int cd_usuario, String nm_nome, String cpf_usuario, String ds_endereco, int nm_agencia,
			int nm_conta) {
		super();
		this.cd_usuario = cd_usuario;
		this.nm_nome = nm_nome;
		this.cpf_usuario = cpf_usuario;
		this.ds_endereco = ds_endereco;
		this.nm_agencia = nm_agencia;
		this.nm_conta = nm_conta;
	}

	public int getCd_usuario() {
		return cd_usuario;
	}

	public void setCd_usuario(int cd_usuario) {
		this.cd_usuario = cd_usuario;
	}

	public String getNm_nome() {
		return nm_nome;
	}

	public void setNm_nome(String nm_nome) {
		this.nm_nome = nm_nome;
	}

	public String getCpf_usuario() {
		return cpf_usuario;
	}

	public void setCpf_usuario(String cpf_usuario) {
		this.cpf_usuario = cpf_usuario;
	}

	public String getDs_endereco() {
		return ds_endereco;
	}

	public void setDs_endereco(String ds_endereco) {
		this.ds_endereco = ds_endereco;
	}

	public int getNm_agencia() {
		return nm_agencia;
	}

	public void setNm_agencia(int nm_agencia) {
		this.nm_agencia = nm_agencia;
	}

	public int getNm_conta() {
		return nm_conta;
	}

	public void setNm_conta(int nm_conta) {
		this.nm_conta = nm_conta;
	}

	

	@Override
	public String toString() {
		return "ProdutoModel [cd_usuario=" + cd_usuario + ", nm_nome=" + nm_nome + ", cpf_usuario=" + cpf_usuario
				+ ", ds_endereco=" + ds_endereco + ", nm_agencia=" + nm_agencia + ", nm_conta=" + nm_conta + "]";
	}
	
	
	



	}

