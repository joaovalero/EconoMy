package br.com.fiap.bancodadoson.view;

import java.sql.SQLException;

import br.com.fiap.bancodadoson.dao.ProdutoDAO;
import br.com.fiap.bancodadoson.model.ProdutoModel;

public class ProdutoUpdateView {

	public static void main(String[] args) throws SQLException {
			
			ProdutoModel model = new ProdutoModel();
			model.setCd_usuario(1);
			model.setNm_nome("Joao teste");
			model.setCpf_usuario("12345678");
			model.setDs_endereco("rua testando");
			model.setNm_agencia(123);
			model.setNm_conta(12356);
			
			
			ProdutoDAO dao = new ProdutoDAO();
			dao.update(model);
			
		}


	}


