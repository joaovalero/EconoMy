package br.com.fiap.bancodadoson.view;

import java.util.List;

import br.com.fiap.bancodadoson.dao.ProdutoDAO;
import br.com.fiap.bancodadoson.model.ProdutoModel;

public class ProdutoListaView {
	
	public static void main(String[] args) {
		
		ProdutoDAO dao = new ProdutoDAO();
		
		List<ProdutoModel> listaProdutos = dao.findAll();
	
 		
 		for (ProdutoModel produtoModel : listaProdutos) {
			System.out.println(produtoModel);
		}
		
	}

}
