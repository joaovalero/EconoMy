package br.com.fiap.bancodadoson.view;

import java.sql.SQLException;

import br.com.fiap.bancodadoson.dao.ProdutoDAO;
import br.com.fiap.bancodadoson.model.ProdutoModel;

public class ProdutoDelete {

	public static void main(String[] args) throws SQLException {
		
		ProdutoModel model = new ProdutoModel();
		model.setCd_usuario(1);
	
		
		ProdutoDAO dao = new ProdutoDAO();
		dao.delete(model);
		
	}


}


