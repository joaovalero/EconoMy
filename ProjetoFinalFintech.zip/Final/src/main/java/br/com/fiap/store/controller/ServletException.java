package br.com.fiap.store.controller;

public class ServletException extends Exception {

}
