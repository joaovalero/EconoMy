package br.com.fiap.store.controller;

public @interface WebServlet {

	String value();

	String value();

}
